package com.app.pojos;

public enum Category {
	PEN,PENCIL,NOTEBOOK,FOLDER,BOOK

}
