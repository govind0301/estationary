package com.app.dao;

import com.app.pojos.OrderDetail;

public interface IOrderDetailDao {
	String addOrderDetail(OrderDetail od);
}
