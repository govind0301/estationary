package com.app.dao;

import com.app.pojos.order1;

public interface IOrderDao {
	String placeOrder(order1 order);
}
